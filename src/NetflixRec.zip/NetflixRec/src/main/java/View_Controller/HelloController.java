package View_Controller;

import DAO.NetflixDao;
import Model.Videos;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    public TableView <Videos> videoTable;
    public TableColumn idCol;
    public TableColumn titleCol;
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("I am initialized.");

        NetflixDao.loadData();
        videoTable.setItems(NetflixDao.videoList);
        idCol.setCellValueFactory(new PropertyValueFactory<>("show_id"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));

    }
}