package Model;

public class HelloApplication {
}
